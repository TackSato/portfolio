package lesson4;
//Playerの子クラス
/**
 * ジャンケンのプレイヤーを表すクラス。
 */
public class Yamada extends Player {
	/**
	 *
	 *
	 * @*param name 名前
	 */
	public Yamada(String name) {
		super(name);
	}

	//------------------------
	// プレイヤークラスの操作
	//------------------------
	/**
	 * ジャンケンの手を出す。
	 *
	 * @return ジャンケンの手
	 */
	public int showHand() {
		//必ずパーを出す
		return PAPER;
	}
}
