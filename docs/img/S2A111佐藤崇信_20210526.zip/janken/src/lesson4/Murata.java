package lesson4;
//Playerの子クラス
/**
 * ジャンケンのプレイヤーを表すクラス。
 */
public class Murata extends Player {
	/**
	 *
	 *
	 * @*param name 名前
	 */
	public Murata(String name) {
		super(name);
	}

	//------------------------
	// プレイヤークラスの操作
	//------------------------
	/**
	 * ジャンケンの手を出す。
	 *
	 * @return ジャンケンの手
	 */
	public int showHand() {
		//必ずグーを出す
		return STONE;
	}
}
