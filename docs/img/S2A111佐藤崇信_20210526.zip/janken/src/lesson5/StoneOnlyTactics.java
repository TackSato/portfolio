package lesson5;

public class StoneOnlyTactics implements Tactics{
/**
 *
 * 戦略を読み、ジャンケンの手を得る。
 * なお、この戦略では必ずグーが戻り値となる。
 *
 * @return ジャンケンの手
 */
	public int readTactics() {
		//必ずグー
		return Player.STONE;
	}


}
