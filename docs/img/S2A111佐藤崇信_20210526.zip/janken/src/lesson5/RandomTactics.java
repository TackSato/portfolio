package lesson5;

import java.util.Random;
/**
 * ランダムに手を決める戦略クラス。
 * @author s20203085
 *
 */
public class RandomTactics implements Tactics{
	/**
	 * 戦略を読み、ジャンケンの手を得る。
	 *
	 * @return ジャンケンの手
	 */
	public int readTactics() {
		Random rand = new Random();
		int playersHand = rand.nextInt(3);
		return playersHand;
	}

}
