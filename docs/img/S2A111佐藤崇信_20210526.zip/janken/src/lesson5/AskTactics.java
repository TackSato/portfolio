package lesson5;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 *
 * 標準入力によりジャンケンの手をユーザに聞く戦略クラス。
 * 戻り値がPlayerクラスで定義されたSTONE、SCISSORS、PAPERのいずれでもない場合、
 * 再度の入力を促す
 * @author s20203085
 *
 */
public class AskTactics implements Tactics{
/**
 * 戦略を読み、ジャンケンの手を得る。
 * @return ジャンケンの手
 */
	public int readTactics() {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		System.out.println("ジャンケンの手を入力してください");
		System.out.println("0:グー");
		System.out.println("1:チョキ");
		System.out.println("2:パー\n");
		System.out.print("?");

		//ジャンケンの手
		int hand=0;

		while(true) {
			try {
				String inputStr=br.readLine();
				hand=Integer.parseInt(inputStr);

				if(hand==Player.STONE
				||hand==Player.SCISSORS
				||hand==Player.PAPER) {
					break;
				}else {
					System.out.println("入力が正しくありません。再度入力してください");
					System.out.print("?");
				}
			}catch(Exception ex) {
				System.out.println("入力が正しくありません。再度入力してください");
				System.out.print("?");
			}
		}

		return hand;
	}


}
