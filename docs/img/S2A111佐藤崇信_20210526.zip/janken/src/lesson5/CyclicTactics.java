package lesson5;

public class CyclicTactics implements Tactics {

	/**最後に出した手(未開始：-1)*/
	int lastHand = -1;

	/**
	 * 戦略を読みジャンケンの手を得る
	 * グー・チョキ・パーのいずれかをPlayerクラスに定義された
	 * 以下の定数で返す
	 * Player.STONE
	 * Player.SCISSORS
	 * Player.PAPER
	 *
	 * @return ジャンケンの手
	 */
	public int readTactics() {
		//最後に出した手を記憶し、次の手を決める
		//グー、チョキ、パーをこのままの順番で出す
		//三回戦以降にも順番を維持
		if (lastHand <Player.PAPER) {
			lastHand = lastHand + 1;

		} else if (Player.PAPER<= lastHand) {
			lastHand =Player.STONE;
		}
		return lastHand;
	}

}
