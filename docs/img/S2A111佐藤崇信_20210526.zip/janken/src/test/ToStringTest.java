package test;

public class ToStringTest {

	public static void main(String[] args) {

		A a=new A("りんご");
		System.out.println(a);
		B b=new B("みかん");
		System.out.println(b.toString());

	}

}

class A {
	private String testdata;

	public A(String data) {
		this.testdata = data;
	}
}

class B {
	private String testdata;

	public B(String data) {
		this.testdata = data;
	}
	@Override
	public String toString() {
		return testdata;
	}
}
