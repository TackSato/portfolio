package test;

import java.util.ArrayList;
//ctrl+Shift+o…自動インポート
public class ArrayListTest {

	public static void main(String[] args) {

		// TODO
		ArrayList<String> array=new ArrayList<String>();

		//追加
		array.add("りんご");
		array.add("みかん");
		array.add("ブドウ");
		array.add("なし");

		String result="";
		result=array.toString();
		System.out.println(result);

		String fruit=(String)array.get(2);
		System.out.println(fruit);
		System.out.println(result);

		String pickFruit=(String)array.remove(2);
		System.out.println(pickFruit);
		result=array.toString();
		System.out.println(result);

		int size=array.size();
		System.out.println(size);
		}

}
