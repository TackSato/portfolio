package test;

public class StringJoinTest {

	public static void main(String[] args) {

		// TODO
		//StringBuffer sb=new StringBuffer();　スレッドセーフ（並行処理時の同期保障のようなもの？）あり
		StringBuilder sb=new StringBuilder();//スレッドセーフなし

		sb.append("Hello ");
		sb.append("World.");
		sb.append("Hello ");
		sb.append("World.");
		sb.append("Hello ");
		sb.append("World.");
		sb.append("Hello ");
		sb.append("World.");
		sb.append("Hello ");
		sb.append("World.");
		sb.append("Hello ");
		sb.append("World.");
		sb.append("Hello ");
		sb.append("World.");
		sb.append("Hello ");
		sb.append("World.");
		sb.append("Hello ");
		sb.append("World.");


		String result=sb.toString();
		System.out.println(result);

	}

}
