package lesson2;

/**
 * オブジェクト指向を使用しないジャンケンプログラム
 */
public class SimpleJanken_3player {
	// ジャンケンの手を表す定数
	public static final int STONE = 0; // グー
	public static final int SCISSORS = 1; // チョキ
	public static final int PAPER = 2; // パー

	// ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
	// 　プログラムのスタートはここから
	// ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
	public static void main(String[] args) {
		// プレイヤー１の勝ち数
		int player1WinCount = 0;

		// プレイヤー２の勝ち数
		int player2WinCount = 0;

		// プレイヤー３の勝ち数
		int player3WinCount = 0;

		// プレイヤー１が出す手
		int player1Hand = 0;

		// プレイヤー２が出す手
		int player2Hand = 0;

		// プレイヤー３が出す手
		int player3Hand = 0;

		// プレイヤー１の名前
		String player1Name = "札幌さん";

		// プレイヤー２の名前
		String player2Name = "旭川さん";

		// プレイヤー３の名前
		String player3Name = "函館さん";

		// ジャンケンの手を決めるのに使用する乱数
		double randomNum = 0;

		// ■■■■■■■■■■■■■■■■■■■■■■■■■■■■
		// 　① プログラムが開始したことを表示する
		// ■■■■■■■■■■■■■■■■■■■■■■■■■■■■
		// プログラム開始メッセージを表示する
		System.out.println("【ジャンケン開始】\n");

		// ジャンケンを３回実施する
		// ■■■■■■■■■■■■■■■■■■■■■■■■■■■■
		// 　⑥ 勝負した回数を加算する
		// 　⑦ ３回勝負が終わったか？
		// ■■■■■■■■■■■■■■■■■■■■■■■■■■■■
		for (int cnt = 0; cnt < 3; cnt++) {
			// 何回戦目かを表示する
			System.out.println("【" + (cnt + 1) + "回戦目】");

			// ■■■■■■■■■■■■■■■■■■■■■■■■■■
			// 　② プレイヤー１が何を出すか決める
			// ■■■■■■■■■■■■■■■■■■■■■■■■■■
			// 0.0以上3.0未満の小数として乱数を得る
			randomNum = Math.random() * 3;

			if (randomNum < 1) {
				// randomNum が 0.0以上1.0未満 の場合、グー
				player1Hand = STONE;

				// プレイヤー１の手を表示する
				System.out.print("グー");
			} else if (randomNum < 2) {
				// randomNum が 1.0以上2.0未満 の場合、チョキ
				player1Hand = SCISSORS;

				// プレイヤー１の手を表示する
				System.out.print("チョキ");
			} else if (randomNum < 3) {
				// randomNum が 2.0以上3.0未満 の場合、パー
				player1Hand = PAPER;

				// プレイヤー１の手を表示する
				System.out.print("パー");
			}

			System.out.print(" vs. ");

			// ■■■■■■■■■■■■■■■■■■■■■■■■■■
			// 　③ プレイヤー２が何を出すか決める
			// ■■■■■■■■■■■■■■■■■■■■■■■■■■
			// 0.0以上3.0未満の小数として乱数を得る
			randomNum = Math.random() * 3;

			if (randomNum < 1) {
				// randomNum が 0.0以上1.0未満 の場合、グー
				player2Hand = STONE;

				// プレイヤー２の手を表示する
				System.out.print("グー");
			} else if (randomNum < 2) {
				// randomNum が 1.0以上2.0未満 の場合、チョキ
				player2Hand = SCISSORS;

				// プレイヤー２の手を表示する
				System.out.print("チョキ");
			} else if (randomNum < 3) {
				// randomNum が 2.0以上3.0未満 の場合、パー
				player2Hand = PAPER;

				// プレイヤー２の手を表示する
				System.out.print("パー");
			}

			System.out.print(" vs. ");

			// ■■■■■■■■■■■■■■■■■■■■■■■■■■
			// 　③ プレイヤー３が何を出すか決める
			// ■■■■■■■■■■■■■■■■■■■■■■■■■■
			// 0.0以上3.0未満の小数として乱数を得る
			randomNum = Math.random() * 3;

			if (randomNum < 1) {
				// randomNum が 0.0以上1.0未満 の場合、グー
				player3Hand = STONE;

				// プレイヤー３の手を表示する
				System.out.println("グー");
			} else if (randomNum < 2) {
				// randomNum が 1.0以上2.0未満 の場合、チョキ
				player3Hand = SCISSORS;

				// プレイヤー３の手を表示する
				System.out.println("チョキ");
			} else if (randomNum < 3) {
				// randomNum が 2.0以上3.0未満 の場合、パー
				player3Hand = PAPER;

				// プレイヤー３の手を表示する
				System.out.println("パー");
			}

			// ■■■■■■■■■■■■■■■■■■■■■■■■■■
			// 　④ だれが勝ちかを判定し、結果を表示する
			//　(A + B + C) ÷ 3 のあまりが
			//　0の場合、あいこ
			//
			//　1の場合、ひとりだけ負け
			//　A = B なら C の負け
			//　B = C なら A の負け
			//　それ以外なら B の負け
			//
			//　2の場合、ひとりだけ勝ち
			//　A = B なら C の勝ち
			//　B = C なら A の勝ち
			//　それ以外なら B の勝ち
			// ■■■■■■■■■■■■■■■■■■■■■■■■■■

			int remainder = (player1Hand + player2Hand + player3Hand) % 3;
			if (remainder == 0) {
				System.out.println("\n引き分けです！\n");
			} else if (remainder == 1) {
				if (player1Hand == player2Hand) {
					System.out.println("\n" + player1Name + "と" + player2Name + "が勝ちました！\n");
					player1WinCount++;
					player2WinCount++;
				} else if (player2Hand == player3Hand) {
					System.out.println("\n" + player2Name + "と" + player3Name + "が勝ちました！\n");
					player2WinCount++;
					player3WinCount++;
				} else {
					System.out.println("\n" + player1Name + "と" + player3Name + "が勝ちました！\n");
					player1WinCount++;
					player3WinCount++;
				}
			} else if (remainder == 2) {
				if (player1Hand == player2Hand) {
					System.out.println("\n" + player3Name + "が勝ちました！\n");
					player3WinCount++;
				} else if (player2Hand == player3Hand) {
					System.out.println("\n" + player1Name + "が勝ちました！\n");
					player1WinCount++;
				} else {
					System.out.println("\n" + player2Name + "が勝ちました！\n");
					player2WinCount++;
				}
			}
		}

		// ■■■■■■■■■■■■■■■■■■■■■■■■■■■■
		// 　⑧ 最終的な勝者を判定し、画面に表示する
		// ■■■■■■■■■■■■■■■■■■■■■■■■■■■■
		System.out.println("【ジャンケン終了】\n");

		if (player1WinCount == player2WinCount && player2WinCount == player3WinCount) {
			// 引き分けを表示する。
			System.out.println(player1WinCount + "対" + player2WinCount + "対" + player3WinCount
					+ "で引き分けです！\n");
		} else if (player1WinCount >= player2WinCount && player2WinCount >= player3WinCount) {
			if (player1WinCount > player2WinCount) {
				// プレイヤー１の勝ち数が多い時
				System.out.println(player1WinCount + "対" + player2WinCount + "対" + player3WinCount
						+ "で" + player1Name + "の勝ちです！\n");
			} else {
				// プレイヤー１、２の勝ち数が多い時
				System.out.println(player1WinCount + "対" + player2WinCount + "対" + player3WinCount
						+ "で" + player1Name + "と" + player2Name + "の勝ちです！\n");
			}
		} else if (player2WinCount >= player3WinCount && player3WinCount >= player1WinCount) {
			if (player2WinCount > player3WinCount) {
				// プレイヤー２の勝ち数が多い時
				System.out.println(player1WinCount + "対" + player2WinCount + "対" + player3WinCount
						+ "で" + player2Name + "の勝ちです！\n");
			} else {
				// プレイヤー２、３の勝ち数が多い時
				System.out.println(player1WinCount + "対" + player2WinCount + "対" + player3WinCount
						+ "で" + player2Name + "と" + player3Name + "の勝ちです！\n");
			}
		} else if (player3WinCount >= player1WinCount && player1WinCount >= player2WinCount) {
			if (player3WinCount > player1WinCount) {
				// プレイヤー３の勝ち数が多い時
				System.out.println(player1WinCount + "対" + player2WinCount + "対" + player3WinCount
						+ "で" + player3Name + "の勝ちです！\n");
			} else {
				// プレイヤー１、３の勝ち数が多い時
				System.out.println(player1WinCount + "対" + player2WinCount + "対" + player3WinCount
						+ "で" + player1Name + "と" + player3Name + "の勝ちです！\n");
			}
		}

	}
}
